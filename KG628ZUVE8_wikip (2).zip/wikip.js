let searchInputEl = document.getElementById("searchInput");
let searchResultsEl = document.getElementById("searchResults");
let spinner = document.getElementById("spinner");
searchInputEl.addEventListener("keydown", searchWikipedia);

function createAndAppendResult(result) {
    // result Item
    let resultEl = document.createElement("div");
    // Title Element
    let {
        link,
        title,
        description
    } = result;
    let titleEl = document.createElement("a");
    titleEl.textContent = title;
    titleEl.target = "_blank";
    titleEl.href = link;
    titleEl.classList.add("result-title");
    resultEl.appendChild(titleEl);
    // Br Element
    let titleBreakEl = document.createElement("br");
    resultEl.appendChild(titleBreakEl);
    // url Element
    let urlEl = document.createElement("a");
    urlEl.textContent = link;
    urlEl.target = "_blank";
    urlEl.href = link;
    urlEl.classList.add("result-url");
    resultEl.appendChild(urlEl);
    // Br Element
    let urlBrEl = document.createElement("br");
    resultEl.appendChild(urlBrEl)
    // Description Element
    let descriptionEl = document.createElement("p");
    descriptionEl.textContent = description;
    descriptionEl.classList.add("link-description");
    resultEl.appendChild(descriptionEl);
    //
    searchResultsEl.appendChild(resultEl);

}

function displayResult(search_results) {
    for (let result of search_results) {
        spinner.classList.add("d-none");
        createAndAppendResult(result);
    }
}

function searchWikipedia(event) {
    if (event.key === "Enter") {
        searchResultsEl.textContent = "";
        spinner.classList.remove("d-none");
        let searchInput = searchInputEl.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                displayResult(search_results);
            });
    }
}